namespace yBook.Helpers
{
    public static class PokojeRepo
    {
        public static List<string> Lista => new()
        {
            "Ma�y pok�j 1",
            "Pok�j dwuosobowy typu Standard 2",
            "Pok�j czteroosobowy typu Classic 3",
            "Pok�j dwuosobowy typu Economy 4",
            "Pok�j czteroosobowy typu Comfort 5",
            "Pok�j Dwuosobowy typu Deluxe 6",
            "Pok�j Dwuosobowy typu Deluxe 7",
            "Pok�j Dwuosobowy typu Deluxe 8",
            "Pok�j Dwuosobowy typu Deluxe 9",
            "Pok�j Dwuosobowy typu Deluxe 10",
            "Pok�j Dwuosobowy typu Deluxe 11"
        };
    }
}